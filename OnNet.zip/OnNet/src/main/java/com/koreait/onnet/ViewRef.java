package com.koreait.onnet;

public class ViewRef {
	public static final String URI_USER = "user";
	public static final String URI_REST = "rest";

	public static final String TEMP_DEFAULT = "template/default";
	public static final String TEMP_MENU_TEMP = "template/menuTemp"; //상위, 하위
}