package com.koreait.onnet.user.model;

public class UserDMI extends UserVO {

}
