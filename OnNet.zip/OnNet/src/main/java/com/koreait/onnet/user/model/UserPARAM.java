package com.koreait.onnet.user.model;

public class UserPARAM extends UserVO {
	private String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}