function test() {

	alert('uuu')
} 